<br>

<div align="center"><strong>📺 MALAYSIA LIVE TV CHANNEL 📺</strong></div>

<br>
<hr>

### RTM

<br>

**TV1 : [Watch](https://zazerconer.github.io/live-tv-malaysia-with-player/channel/rtm/tv1/)**

```url
https://zazerconer.github.io/live-tv-malaysia-with-player/channel/rtm/tv1/index.html
```

**TV2 : [Watch](https://zazerconer.github.io/live-tv-malaysia-with-player/channel/rtm/tv2/)**

```url
https://zazerconer.github.io/live-tv-malaysia-with-player/channel/rtm/tv2/index.html
```

**TV6 : [Watch](https://zazerconer.github.io/live-tv-malaysia-with-player/channel/rtm/tv6/)**

```url
https://zazerconer.github.io/live-tv-malaysia-with-player/channel/rtm/tv6/index.html
```

**TV Okey : [Watch](https://zazerconer.github.io/live-tv-malaysia-with-player/channel/rtm/tv-okey/)**

```url
https://zazerconer.github.io/live-tv-malaysia-with-player/channel/rtm/tv-okey/index.html
```

**Berita RTM : [Watch](https://zazerconer.github.io/live-tv-malaysia-with-player/channel/rtm/berita-rtm/)**

```url
https://zazerconer.github.io/live-tv-malaysia-with-player/channel/rtm/berita-rtm/index.html
```

**Sukan RTM : [Watch](https://zazerconer.github.io/live-tv-malaysia-with-player/channel/rtm/sukan-rtm/)**

```url
https://zazerconer.github.io/live-tv-malaysia-with-player/channel/rtm/sukan-rtm/index.html
```

<br>

### Media Prima

<br>

**TV3 : [Watch](https://zazerconer.github.io/live-tv-malaysia-with-player/channel/media-prima/tv3/)**

```url
https://zazerconer.github.io/live-tv-malaysia-with-player/channel/media-prima/tv3/index.html
```

**Didik TV : [Watch](https://zazerconer.github.io/live-tv-malaysia-with-player/channel/media-prima/didik-tv/)**

```url
https://zazerconer.github.io/live-tv-malaysia-with-player/channel/media-prima/didik-tv/index.html
```

**8TV : [Watch](https://zazerconer.github.io/live-tv-malaysia-with-player/channel/media-prima/8tv/)**

```url
https://zazerconer.github.io/live-tv-malaysia-with-player/channel/media-prima/8tv/index.html
```

**TV9 : [Watch](https://zazerconer.github.io/live-tv-malaysia-with-player/channel/media-prima/tv9/)**

```url
https://zazerconer.github.io/live-tv-malaysia-with-player/channel/media-prima/tv9/index.html
```

<br>

### MyFreeView

<br>

**AWANI : [Watch](https://zazerconer.github.io/live-tv-malaysia-with-player/channel/myfreeview/awani/)**

```url
https://zazerconer.github.io/live-tv-malaysia-with-player/channel/myfreeview/awani/index.html
```

**TV IKIM : [Watch](https://zazerconer.github.io/live-tv-malaysia-with-player/channel/myfreeview/tv-ikim/)**

```url
https://zazerconer.github.io/live-tv-malaysia-with-player/channel/myfreeview/tv-ikim/index.html
```

**TVS : [Watch](https://zazerconer.github.io/live-tv-malaysia-with-player/channel/myfreeview/tvs/)**

```url
https://zazerconer.github.io/live-tv-malaysia-with-player/channel/myfreeview/tvs/index.html
```

<hr>
<br>

### Embed Player

<code><iframe></code>

```js
 <div style="position:relative;width:90%;padding-bottom:56.25%;display:block;margin:auto;">
   <iframe
     src="https://url"
     width="100%" height="100%"
     style="position:absolute;top:0;left:0;"
     frameborder="0"
     allow="fullscreen;autoplay;accelerometer;encrypted-media;gyroscope;picture-in-picture"
     referrerpolicy="no-referrer">
   </iframe>
 </div> 
```

<hr>
<br>
<br>

> [!WARNING]
>
> All above **TV channels** may not work or cannot be viewed in some regions.

<br>
